﻿namespace ProjetoCaçaPalavras
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelGrade = new Panel();
            listBoxPalavras = new ListBox();
            btnNovoJogo = new Button();
            btnVerificar = new Button();
            btnRanking = new Button();
            btnSair = new Button();
            lblStatus = new Label();
            listBoxRanking = new ListBox();
            SuspendLayout();
            // 
            // panelGrade
            // 
            panelGrade.BackColor = Color.White;
            panelGrade.BorderStyle = BorderStyle.FixedSingle;
            panelGrade.Location = new Point(20, 20);
            panelGrade.Name = "panelGrade";
            panelGrade.Size = new Size(352, 353);
            panelGrade.TabIndex = 0;
            panelGrade.Paint += panelGrade_Paint;
            // 
            // listBoxPalavras
            // 
            listBoxPalavras.FormattingEnabled = true;
            listBoxPalavras.ItemHeight = 15;
            listBoxPalavras.Location = new Point(390, 20);
            listBoxPalavras.Name = "listBoxPalavras";
            listBoxPalavras.Size = new Size(150, 199);
            listBoxPalavras.TabIndex = 1;
            listBoxPalavras.SelectedIndexChanged += listBoxPalavras_SelectedIndexChanged;
            // 
            // btnNovoJogo
            // 
            btnNovoJogo.Location = new Point(390, 252);
            btnNovoJogo.Name = "btnNovoJogo";
            btnNovoJogo.Size = new Size(150, 23);
            btnNovoJogo.TabIndex = 2;
            btnNovoJogo.Text = "NOVO JOGO";
            btnNovoJogo.UseVisualStyleBackColor = true;
            btnNovoJogo.Click += btnNovoJogo_Click;
            // 
            // btnVerificar
            // 
            btnVerificar.Location = new Point(390, 281);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(150, 23);
            btnVerificar.TabIndex = 3;
            btnVerificar.Text = "VERIFICAR";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // btnRanking
            // 
            btnRanking.Location = new Point(564, 252);
            btnRanking.Name = "btnRanking";
            btnRanking.Size = new Size(150, 23);
            btnRanking.TabIndex = 4;
            btnRanking.Text = "RANKING";
            btnRanking.UseVisualStyleBackColor = true;
            btnRanking.Click += btnRanking_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(712, 397);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(76, 41);
            btnSair.TabIndex = 5;
            btnSair.Text = "SAIR";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(416, 222);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(97, 15);
            lblStatus.TabIndex = 6;
            lblStatus.Text = "CAÇA PALAVRAS";
            lblStatus.Click += lblStatus_Click;
            // 
            // listBoxRanking
            // 
            listBoxRanking.FormattingEnabled = true;
            listBoxRanking.ItemHeight = 15;
            listBoxRanking.Location = new Point(564, 20);
            listBoxRanking.Name = "listBoxRanking";
            listBoxRanking.Size = new Size(150, 199);
            listBoxRanking.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listBoxRanking);
            Controls.Add(lblStatus);
            Controls.Add(btnSair);
            Controls.Add(btnRanking);
            Controls.Add(btnVerificar);
            Controls.Add(btnNovoJogo);
            Controls.Add(listBoxPalavras);
            Controls.Add(panelGrade);
            Name = "Form1";
            Text = "Caça Palavras";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelGrade;
        private ListBox listBoxPalavras;
        private Button btnNovoJogo;
        private Button btnVerificar;
        private Button btnRanking;
        private Button btnSair;
        private Label lblStatus;
        private ListBox listBoxRanking;
    }
}

using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;
using System.Data;

namespace ProjetoCaçaPalavras
{
    public partial class Form1 : Form
    {

        private char[,] grade = new char[10, 10];
        private List<string> palavras;
        private List<Label> letrasSelecionadas = new List<Label>();
        private int linhas = 10, colunas = 10;
        private int tamanhoCelula = 35;
        private string jogadorNome;
        private int pontuacao;
        private string connStr = "server=localhost;database=cacapalavras;uid=root;pwd=root;";


        public Form1()
        {
            InitializeComponent();
        }

        public Form1(string nome, int pontos)
        {
            InitializeComponent();
            jogadorNome = nome;
            pontuacao = pontos;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            novojogo();
        }

        private void novojogo()
        {
            panelGrade.Controls.Clear();
            listBoxPalavras.Items.Clear();
            letrasSelecionadas.Clear();

            grade = new char[linhas, colunas];
            palavras = new List<string> { "CODIGO", "PET", "CASA", "LER" };



            insercaoPalavras();

            Random rnd = new Random();
            for (int i = 0; i < linhas; i++)
            {
                for (int j = 0; j < colunas; j++)
                {
                    if (grade[i, j] == '\0')
                        grade[i, j] = (char)('A' + rnd.Next(0, 26));
                }
            }

            
            foreach (var p in palavras)
                listBoxPalavras.Items.Add(p);

            
            gradeExibir();

        }

        private void adicionarPontuacao(int pontosGanhos)
        {
            pontuacao += pontosGanhos;
            this.Text = $"Caça-Palavras - Jogador: {jogadorNome} | Pontos: {pontuacao}";
        }

        private void salvarPontuacao()
        {
            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();
                string sql = "UPDATE login SET pontuacao = GREATEST(pontuacao, @pontos) WHERE nome = @nome";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@pontos", pontuacao);
                cmd.Parameters.AddWithValue("@nome", jogadorNome);
                cmd.ExecuteNonQuery();
            }
        }

        private void atualizarRanking()
        {
            listBoxRanking.Items.Clear();

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();
                string sql = "SELECT nome, pontuacao FROM login ORDER BY pontuacao DESC, nome ASC";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string nome = reader.GetString("nome");
                        int pontos = reader.GetInt32("pontuacao");

                        listBoxRanking.Items.Add($"{nome} - {pontos} pontos");
                    }
                }
            }
        }


        private void insercaoPalavras()
        {
            Random rnd = new Random();

            foreach (string palavra in palavras)
            {
                bool colocada = false;

                while (!colocada)
                {
                    int linha = rnd.Next(linhas);
                    int coluna = rnd.Next(colunas);
                    bool horizontal = rnd.Next(2) == 0;

                    if (horizontal && coluna + palavra.Length <= colunas)
                    {
                        bool podeColocar = true;
                        for (int i = 0; i < palavra.Length; i++)
                        {
                            char c = grade[linha, coluna + i];
                            if (c != '\0' && c != palavra[i])
                            {
                                podeColocar = false;
                                break;
                            }
                        }

                        if (podeColocar)
                        {
                            for (int i = 0; i < palavra.Length; i++)
                                grade[linha, coluna + i] = palavra[i];

                            colocada = true;
                        }
                    }
                    else if (!horizontal && linha + palavra.Length <= linhas)
                    {
                        bool podeColocar = true;
                        for (int i = 0; i < palavra.Length; i++)
                        {
                            char c = grade[linha + i, coluna];
                            if (c != '\0' && c != palavra[i])
                            {
                                podeColocar = false;
                                break;
                            }
                        }

                        if (podeColocar)
                        {
                            for (int i = 0; i < palavra.Length; i++)
                                grade[linha + i, coluna] = palavra[i];

                            colocada = true;
                        }
                    }
                }
            }
        }

        private void gradeExibir()
        {
            for (int i = 0; i < linhas; i++)
            {
                for (int j = 0; j < colunas; j++)
                {
                    Label lbl = new Label();
                    lbl.Text = grade[i, j].ToString();
                    lbl.Size = new Size(tamanhoCelula, tamanhoCelula);
                    lbl.Location = new Point(j * tamanhoCelula, i * tamanhoCelula);
                    lbl.TextAlign = ContentAlignment.MiddleCenter;
                    lbl.Font = new Font("Arial", 14, FontStyle.Bold);
                    lbl.BorderStyle = BorderStyle.FixedSingle;
                    lbl.BackColor = Color.White;
                    lbl.Click += Letra_Click;
                    panelGrade.Controls.Add(lbl);
                }
            }
        }

        private void Letra_Click(object? sender, EventArgs e)
        {
            if (sender is not Label lbl) return;

            if (lbl.BackColor == Color.Yellow)
            {
                lbl.BackColor = Color.White;
                letrasSelecionadas.Remove(lbl);
            }
            else
            {
                lbl.BackColor = Color.Yellow;
                letrasSelecionadas.Add(lbl);
            }
        }


        private void panelGrade_Paint(object sender, PaintEventArgs e)
        {

        }

        private void listBoxPalavras_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnNovoJogo_Click(object sender, EventArgs e)
        {
            novojogo();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string palavraSelecionada = "";
            foreach (var lbl in letrasSelecionadas)
                palavraSelecionada += lbl.Text;

            palavraSelecionada = palavraSelecionada.ToUpper();

            if (palavras.Contains(palavraSelecionada))
            {
                lblStatus.Text = $"Você encontrou: {palavraSelecionada}!";
                foreach (var lbl in letrasSelecionadas)
                lbl.BackColor = Color.LightGreen;
                adicionarPontuacao(10);
                salvarPontuacao();
                atualizarRanking();

                listBoxPalavras.Items.Remove(palavraSelecionada);
                letrasSelecionadas.Clear();

                if (listBoxPalavras.Items.Count == 0)
                    lblStatus.Text = "Você encontrou todas as palavras!";
            }
            else
            {
                lblStatus.Text = "Palavra incorreta!";
                foreach (var lbl in letrasSelecionadas)
                lbl.BackColor = Color.White;
                letrasSelecionadas.Clear();
            }
        }

        private void btnRanking_Click(object sender, EventArgs e)
        {
            listBoxRanking.Items.Clear();

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();
                string sql = "SELECT nome, pontuacao FROM login ORDER BY pontuacao DESC, nome ASC";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string nome = reader.GetString("nome");
                        int pontos = reader.GetInt32("pontuacao");

                        
                        listBoxRanking.Items.Add($"{nome} - {pontos} pontos");
                    }
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }
    }
}

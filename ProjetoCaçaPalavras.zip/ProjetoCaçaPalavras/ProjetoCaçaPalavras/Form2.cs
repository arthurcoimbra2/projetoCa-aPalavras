﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCaçaPalavras
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text.Trim();

            if (string.IsNullOrEmpty(nome))
            {
                MessageBox.Show("Digite um nome válido!", "Erro");
                return;
            }
            int pontuacao = 0;

            string connStr = "server=localhost;database=cacapalavras;uid=root;pwd=root;";

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();
                string sql = "SELECT pontuacao FROM login WHERE nome = @nome";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@nome", nome);

                object result = cmd.ExecuteScalar();

                if (result != null)
                {
                    pontuacao = Convert.ToInt32(result);
                }
                else
                {
                    string insert = "INSERT INTO login (nome, pontuacao) VALUES (@nome, 0)";
                    MySqlCommand cmdInsert = new MySqlCommand(insert, conn);
                    cmdInsert.Parameters.AddWithValue("@nome", nome);
                    cmdInsert.ExecuteNonQuery();
                }
            }



            Form1 jogo = new Form1(nome, pontuacao);
            jogo.Show();

            
            this.Hide();
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
